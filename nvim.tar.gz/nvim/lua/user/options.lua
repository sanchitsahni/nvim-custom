local options = {
	-- Example
	autoindent = true,
}

return options
