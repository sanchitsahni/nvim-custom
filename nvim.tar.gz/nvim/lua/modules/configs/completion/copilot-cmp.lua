return function()
	require("modules.utils").load_plugin("copilot_cmp", {})
end
