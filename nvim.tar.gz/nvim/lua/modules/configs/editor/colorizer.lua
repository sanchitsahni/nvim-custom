return function()
	require("modules.utils").load_plugin("colorizer", {})
end
