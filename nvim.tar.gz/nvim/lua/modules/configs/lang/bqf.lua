return function()
	require("modules.utils").load_plugin("bqf", {
		preview = {
			border = "single",
			wrap = true,
			winblend = 0,
		},
	})
end
